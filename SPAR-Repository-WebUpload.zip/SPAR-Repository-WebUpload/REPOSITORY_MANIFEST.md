# Repository Manifest

Upload the complete folder to GitHub. The important files are:

## Core SPAR method

- `src/spar/detection.py` — Stage 1 dual-view spectral/structural detector
- `src/spar/purification.py` — Stage 2 loss-based purification with feature retention
- `src/spar/revalidation.py` — Stage 3 adaptive revalidation
- `src/spar/sanitizer.py` — Stage 4 test-time sanitizer
- `src/spar/pipeline.py` — end-to-end SPAR orchestration
- `src/spar/attack.py` — frozen attack generator used for controlled comparisons
- `src/spar/models.py` — GCN, GAT, and GraphSAGE
- `src/spar/data.py` — Cora/CiteSeer/PubMed loading
- `src/spar/metrics.py` — CA, ASR, DR, FPR, precision, and F1

## Experiment entry points

- `experiments/run_spar.py` — single main experiment
- `experiments/spar_architecture_sweep.py` — 27-run GCN/GAT/GraphSAGE transfer study
- `experiments/run_ablation.py` — SPAR stage ablations
- `experiments/run_robustness.py` — poisoning-rate and trigger-size robustness
- `experiments/run_efficiency.py` — runtime and memory measurements
- `experiments/run_multi_seed.py` — multi-seed validation
- `experiments/run_baselines.py` — official DShield/RIGBD command runner
- `experiments/setup_third_party.py` — restores large third-party assets in the web-upload archive

## Baselines

- `third_party/DShield/` — official DShield implementation
- `third_party/RIGBD/` — official RIGBD implementation

## Configuration and metadata

- `configs/default.yaml`
- `configs/cora.yaml`
- `configs/citeseer.yaml`
- `configs/pubmed.yaml`
- `configs/architecture_sweep.yaml`
- `README.md`
- `docs/REPRODUCIBILITY.md`
- `THIRD_PARTY_NOTICES.md`
- `requirements.txt`
- `environment.yml`
- `pyproject.toml`
- `LICENSE`
- `CITATION.cff`
- `.gitignore`

## Deliberately excluded

- SSP-only method code
- SSP paper plotting scripts
- obsolete experiments using the wrong protocol
- temporary logs and local checkpoints
- exploratory duplicate scripts not used in the SPAR paper
