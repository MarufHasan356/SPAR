# Third-Party Notices

This repository retains official comparison implementations so reviewers can inspect and run the defenses reported in the SPAR paper without confusing them with the proposed SPAR method.

## DShield

- Directory: `third_party/DShield/`
- Source: <https://github.com/csyuhao/DShield>
- Paper: Hao Yu et al., “DShield: Defending against Backdoor Attacks on Graph Neural Networks via Discrepancy Learning,” NDSS 2025.
- License: MIT; see `third_party/DShield/LICENSE`.
- Status: official source retained for baseline reproducibility.

Suggested citation:

```bibtex
@inproceedings{yu2025dshield,
  author    = {Hao Yu and Chuan Ma and Xinhang Wan and Jun Wang and Tao Xiang and Meng Shen and Xinwang Liu},
  title     = {DShield: Defending against Backdoor Attacks on Graph Neural Networks via Discrepancy Learning},
  booktitle = {Network and Distributed System Security Symposium},
  year      = {2025}
}
```

## RIGBD

- Directory: `third_party/RIGBD/`
- Source: <https://github.com/zzwjames/RIGBD>
- Paper: Zhiwei Zhang et al., “Robustness Inspired Graph Backdoor Defense,” ICLR 2025.
- License: no license file was present in the official source snapshot. Copyright remains with the original authors.
- Status: official source retained for baseline reproducibility.

Suggested citation:

```bibtex
@inproceedings{zhang2025rigbd,
  author    = {Zhiwei Zhang and Minhua Lin and Junjie Xu and Zongyu Wu and Enyan Dai and Suhang Wang},
  title     = {Robustness Inspired Graph Backdoor Defense},
  booktitle = {The Thirteenth International Conference on Learning Representations},
  year      = {2025}
}
```

## Redistribution note

If you prefer not to redistribute third-party code in your public GitHub repository, replace these directories with Git submodules pointing to the official repositories. The SPAR source under `src/spar/` does not import either baseline implementation.
