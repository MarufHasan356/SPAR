#!/usr/bin/env python3
"""Run SPAR stage ablations."""

from __future__ import annotations

import argparse
import csv
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

ABLATIONS = {
    "full": [],
    "no_detection": ["detection"],
    "no_purification": ["purification"],
    "no_revalidation": ["revalidation"],
    "no_sanitizer": ["sanitizer"],
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run SPAR component ablations.")
    parser.add_argument("--dataset", default="Cora", choices=["Cora", "CiteSeer", "PubMed"])
    parser.add_argument("--architecture", default="gcn", choices=["gcn", "gat", "graphsage"])
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--device", default="auto")
    parser.add_argument("--output", default=str(ROOT / "results" / "ablation.csv"))
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    rows = []
    for name, stages in ABLATIONS.items():
        command = [
            sys.executable,
            str(ROOT / "experiments" / "run_spar.py"),
            "--dataset", args.dataset,
            "--architecture", args.architecture,
            "--seed", str(args.seed),
            "--device", args.device,
            "--output", str(Path(args.output).parent / "ablation_runs"),
        ]
        for stage in stages:
            command.extend(["--disable-stage", stage])
        completed = subprocess.run(command, cwd=ROOT, check=True, text=True, capture_output=True)
        row = json.loads(completed.stdout[completed.stdout.find("{"):])
        row["ablation"] = name
        rows.append(row)

    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = sorted({key for row in rows for key in row})
    with output.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow({key: json.dumps(value) if isinstance(value, (list, dict)) else value for key, value in row.items()})
    print(f"Saved {len(rows)} ablation runs to {output}")


if __name__ == "__main__":
    main()
