#!/usr/bin/env python3
"""Run one SPAR experiment."""

from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from spar.data import describe_split, load_planetoid
from spar.pipeline import SPARConfig, SPARPipeline
from spar.utils import deep_update, ensure_dir, load_config, save_json


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run SPAR on a Planetoid citation graph.")
    parser.add_argument("--dataset", default="Cora", choices=["Cora", "CiteSeer", "PubMed"])
    parser.add_argument("--architecture", default=None, choices=["gcn", "gat", "graphsage"])
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--defense", default="spar", choices=["spar", "none"])
    parser.add_argument("--device", default="auto")
    parser.add_argument("--output", default="results")
    parser.add_argument(
        "--disable-stage",
        action="append",
        default=[],
        choices=["detection", "purification", "revalidation", "sanitizer"],
        help="Disable one SPAR stage for ablation; repeatable.",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    dataset_key = args.dataset.lower()
    config = load_config(ROOT / "configs" / "default.yaml", ROOT / "configs" / f"{dataset_key}.yaml")
    if args.architecture is not None:
        config = deep_update(config, {"model": {"architecture": args.architecture}})

    clean_data = load_planetoid(args.dataset, config.get("data", {}).get("root", ROOT / "data"))
    pipeline_config = SPARConfig.from_dict(
        config,
        seed=args.seed,
        defense=args.defense,
        disabled_stages=set(args.disable_stage),
    )
    result = SPARPipeline(pipeline_config, device=args.device).run(clean_data)
    result.update({
        "dataset": args.dataset,
        "architecture": config.get("model", {}).get("architecture", "gcn"),
        "seed": args.seed,
        **{f"split_{key}": value for key, value in describe_split(clean_data).items()},
    })

    output_dir = ensure_dir(args.output)
    stem = f"{args.defense}_{args.dataset.lower()}_{result['architecture']}_seed{args.seed}"
    save_json(result, output_dir / f"{stem}.json")

    csv_path = output_dir / "experiment_results.csv"
    write_header = not csv_path.exists()
    serializable = {key: json.dumps(value) if isinstance(value, (list, dict)) else value for key, value in result.items()}
    with csv_path.open("a", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=sorted(serializable))
        if write_header:
            writer.writeheader()
        writer.writerow(serializable)

    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
