#!/usr/bin/env python3
"""Run the frozen-attack architecture transfer sweep: 3 datasets × 3 models × 3 seeds."""

from __future__ import annotations

import argparse
import csv
import json
import subprocess
import sys
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run the 27-run SPAR architecture sweep.")
    parser.add_argument("--config", default=str(ROOT / "configs" / "architecture_sweep.yaml"))
    parser.add_argument("--device", default="auto")
    parser.add_argument("--output", default=str(ROOT / "results" / "architecture_sweep.csv"))
    parser.add_argument("--continue-on-error", action="store_true")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    with Path(args.config).open("r", encoding="utf-8") as handle:
        sweep = yaml.safe_load(handle)

    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    rows: list[dict] = []

    for dataset in sweep["datasets"]:
        for architecture in sweep["architectures"]:
            for seed in sweep["seeds"]:
                command = [
                    sys.executable,
                    str(ROOT / "experiments" / "run_spar.py"),
                    "--dataset", str(dataset),
                    "--architecture", str(architecture),
                    "--seed", str(seed),
                    "--defense", "spar",
                    "--device", args.device,
                    "--output", str(output.parent / "architecture_runs"),
                ]
                print("Running:", " ".join(command), flush=True)
                completed = subprocess.run(command, cwd=ROOT, text=True, capture_output=True)
                if completed.returncode != 0:
                    message = completed.stderr.strip() or completed.stdout.strip()
                    if not args.continue_on_error:
                        raise RuntimeError(f"Sweep run failed: {message}")
                    rows.append({
                        "dataset": dataset,
                        "architecture": architecture,
                        "seed": seed,
                        "error": message,
                    })
                    continue
                result = json.loads(completed.stdout[completed.stdout.find("{"):])
                rows.append(result)

    if rows:
        fieldnames = sorted({key for row in rows for key in row})
        with output.open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=fieldnames)
            writer.writeheader()
            for row in rows:
                writer.writerow({key: json.dumps(value) if isinstance(value, (list, dict)) else value for key, value in row.items()})
    print(f"Saved {len(rows)} runs to {output}")


if __name__ == "__main__":
    main()
