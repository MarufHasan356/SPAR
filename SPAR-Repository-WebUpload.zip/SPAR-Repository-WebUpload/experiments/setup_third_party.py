#!/usr/bin/env python3
"""Download large third-party baseline assets excluded from the web-upload archive."""

from __future__ import annotations

import argparse
import shutil
import tempfile
import urllib.request
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCES = {
    "DShield": "https://codeload.github.com/csyuhao/DShield/zip/refs/heads/main",
    "RIGBD": "https://codeload.github.com/zzwjames/RIGBD/zip/refs/heads/master",
}


def download_archive(name: str, url: str, destination: Path) -> Path:
    archive = destination / f"{name}.zip"
    print(f"Downloading {name}: {url}")
    urllib.request.urlretrieve(url, archive)
    with zipfile.ZipFile(archive) as handle:
        handle.extractall(destination)
    archive.unlink()
    roots = [path for path in destination.iterdir() if path.is_dir()]
    if len(roots) != 1:
        raise RuntimeError(f"Could not identify extracted directory for {name}: {roots}")
    return roots[0]


def main() -> None:
    parser = argparse.ArgumentParser(description="Restore official DShield/RIGBD source and large assets.")
    parser.add_argument("--method", choices=["all", "dshield", "rigbd"], default="all")
    args = parser.parse_args()

    methods = ["dshield", "rigbd"] if args.method == "all" else [args.method]
    for method in methods:
        name = "DShield" if method == "dshield" else "RIGBD"
        target = ROOT / "third_party" / name
        target.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory() as temporary:
            extracted = download_archive(name, SOURCES[name], Path(temporary))
            shutil.copytree(extracted, target, dirs_exist_ok=True)
        print(f"Restored {name} into {target}")

    print("Third-party setup complete.")


if __name__ == "__main__":
    main()
