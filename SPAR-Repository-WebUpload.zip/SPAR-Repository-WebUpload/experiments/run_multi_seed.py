#!/usr/bin/env python3
"""Run SPAR across multiple seeds and summarize mean/std metrics."""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run a multi-seed SPAR validation.")
    parser.add_argument("--dataset", default="Cora", choices=["Cora", "CiteSeer", "PubMed"])
    parser.add_argument("--architecture", default="gcn", choices=["gcn", "gat", "graphsage"])
    parser.add_argument("--seeds", nargs="+", type=int, default=[0, 1, 2, 3, 4])
    parser.add_argument("--device", default="auto")
    parser.add_argument("--output", default=str(ROOT / "results"))
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    rows = []
    for seed in args.seeds:
        command = [
            sys.executable,
            str(ROOT / "experiments" / "run_spar.py"),
            "--dataset", args.dataset,
            "--architecture", args.architecture,
            "--seed", str(seed),
            "--device", args.device,
            "--output", str(output / "multi_seed_runs"),
        ]
        subprocess.run(command, cwd=ROOT, check=True, text=True, capture_output=True)

    run_files = sorted((output / "multi_seed_runs").glob(f"spar_{args.dataset.lower()}_{args.architecture}_seed*.json"))
    for path in run_files:
        rows.append(json.loads(path.read_text(encoding="utf-8")))
    frame = pd.DataFrame(rows)
    numeric = frame.select_dtypes(include="number")
    summary = pd.DataFrame({"mean": numeric.mean(), "std": numeric.std(ddof=1)})
    summary_path = output / f"multi_seed_summary_{args.dataset.lower()}_{args.architecture}.csv"
    summary.to_csv(summary_path)
    print(summary.to_string())
    print(f"Saved summary to {summary_path}")


if __name__ == "__main__":
    main()
