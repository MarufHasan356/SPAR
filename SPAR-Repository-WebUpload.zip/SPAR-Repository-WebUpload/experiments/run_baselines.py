#!/usr/bin/env python3
"""Commands for official DShield and RIGBD baseline comparisons."""

from __future__ import annotations

import argparse
import shlex
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def _baseline_dataset_name(dataset: str) -> str:
    return {"cora": "Cora", "citeseer": "Citeseer", "pubmed": "Pubmed"}[dataset.lower()]


def dshield_command(dataset: str, seed: int) -> tuple[Path, list[str]]:
    cwd = ROOT / "third_party" / "DShield" / "NodeClassificationTasks"
    command = [
        sys.executable,
        "main.py",
        f"--seed={seed}",
        "--model=GCN",
        f"--dataset={_baseline_dataset_name(dataset)}",
        "--benign_epochs=200",
        "--trigger_size=3",
        "--vs_number=40" if dataset.lower() == "pubmed" else "--vs_number=10",
        "--use_vs_number",
        "--target_class=1",
        "--selection_method=cluster_degree",
        "--attack_method=UGBA",
        "--ugba_thrd=0.5",
        "--ugba_trojan_epochs=200",
        "--ugba_inner_epochs=5",
        "--ugba_target_loss_weight=5",
        "--ugba_homo_loss_weight=50",
        "--ugba_homo_boost_thrd=1.0",
        "--defense_method=DShield",
        "--dshield_pretrain_epochs=400",
        "--dshield_finetune_epochs=400",
        "--dshield_classify_epochs=400",
        "--dshield_kappa1=5",
        "--dshield_kappa2=5",
        "--dshield_kappa3=0.1",
        "--dshield_edge_drop_ratio=0.20",
        "--dshield_feature_drop_ratio=0.20",
        "--dshield_tau=0.9",
        "--dshield_balance_factor=0.5",
        "--dshield_classify_rounds=1",
        "--dshield_thresh=2.5",
    ]
    return cwd, command


def rigbd_command(dataset: str, seed: int) -> tuple[Path, list[str]]:
    cwd = ROOT / "third_party" / "RIGBD"
    if dataset.lower() != "cora":
        raise ValueError(
            "The official RIGBD repository packages Cora assets only. Download the authors' "
            "PubMed/CiteSeer/arXiv files and update the paths below before running another dataset."
        )
    command = [
        sys.executable,
        "defense.py",
        "--dataset", "Cora",
        "--seed", str(seed),
        "--vs_number", "40",
        "--trigger_generator_address", "./model_weights_cora.pth",
        "--poison_x", "poison_x_cora.pt",
        "--poison_edge_index", "poison_edge_index_cora.pt",
        "--poison_edge_weights", "poison_edge_weights_cora.pt",
        "--poison_labels", "poison_labels_cora.pt",
        "--idx_attach", "Cora_UGBA.txt",
    ]
    return cwd, command


def main() -> None:
    parser = argparse.ArgumentParser(description="Print or execute official baseline commands.")
    parser.add_argument("--method", required=True, choices=["dshield", "rigbd"])
    parser.add_argument("--dataset", default="Cora", choices=["Cora", "CiteSeer", "PubMed"])
    parser.add_argument("--seed", type=int, default=1027)
    parser.add_argument("--execute", action="store_true")
    args = parser.parse_args()

    builder = dshield_command if args.method == "dshield" else rigbd_command
    cwd, command = builder(args.dataset, args.seed)
    print(f"Working directory: {cwd}")
    print("Command:", shlex.join(command))
    if args.execute:
        subprocess.run(command, cwd=cwd, check=True)


if __name__ == "__main__":
    main()
