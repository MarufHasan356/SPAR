#!/usr/bin/env python3
"""Robustness sweeps over poisoning rate and trigger size."""

from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from spar.data import load_planetoid
from spar.pipeline import SPARConfig, SPARPipeline
from spar.utils import deep_update, load_config


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Evaluate SPAR robustness under varied attack budgets.")
    parser.add_argument("--dataset", default="Cora", choices=["Cora", "CiteSeer", "PubMed"])
    parser.add_argument("--architecture", default="gcn", choices=["gcn", "gat", "graphsage"])
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--mode", choices=["poisoning-rate", "trigger-size"], default="poisoning-rate")
    parser.add_argument("--device", default="auto")
    parser.add_argument("--output", default=str(ROOT / "results" / "robustness.csv"))
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    config_path = ROOT / "configs" / f"{args.dataset.lower()}.yaml"
    base_config = load_config(ROOT / "configs" / "default.yaml", config_path)
    base_config = deep_update(base_config, {"model": {"architecture": args.architecture}})
    clean_data = load_planetoid(args.dataset, base_config.get("data", {}).get("root", ROOT / "data"))

    if args.mode == "poisoning-rate":
        settings = [(ratio, None) for ratio in [0.01, 0.025, 0.05, 0.10]]
    else:
        settings = [(None, size) for size in [1, 3, 5, 7]]

    rows = []
    for ratio, trigger_size in settings:
        config = dict(base_config)
        if ratio is not None:
            config = deep_update(config, {"attack": {"train_poison_ratio": ratio, "test_poison_ratio": ratio}})
        if trigger_size is not None:
            config = deep_update(config, {"attack": {"trigger_size": trigger_size}})
        pipeline = SPARPipeline(SPARConfig.from_dict(config, seed=args.seed), device=args.device)
        row = pipeline.run(clean_data)
        row.update({
            "dataset": args.dataset,
            "architecture": args.architecture,
            "mode": args.mode,
            "train_poison_ratio": config["attack"]["train_poison_ratio"],
            "test_poison_ratio": config["attack"]["test_poison_ratio"],
            "trigger_size": config["attack"]["trigger_size"],
        })
        rows.append(row)
        print(json.dumps(row, indent=2, sort_keys=True), flush=True)

    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = sorted({key for row in rows for key in row})
    with output.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow({key: json.dumps(value) if isinstance(value, (list, dict)) else value for key, value in row.items()})
    print(f"Saved robustness sweep to {output}")


if __name__ == "__main__":
    main()
