#!/usr/bin/env python3
"""Measure SPAR end-to-end runtime and accelerator memory."""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from spar.data import load_planetoid
from spar.pipeline import SPARConfig, SPARPipeline
from spar.utils import deep_update, load_config, save_json


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Measure SPAR runtime and memory usage.")
    parser.add_argument("--dataset", default="Cora", choices=["Cora", "CiteSeer", "PubMed"])
    parser.add_argument("--architecture", default="gcn", choices=["gcn", "gat", "graphsage"])
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--device", default="auto")
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--output", default=str(ROOT / "results" / "efficiency.json"))
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    config = load_config(ROOT / "configs" / "default.yaml", ROOT / "configs" / f"{args.dataset.lower()}.yaml")
    config = deep_update(config, {"model": {"architecture": args.architecture}})
    data = load_planetoid(args.dataset, config.get("data", {}).get("root", ROOT / "data"))

    runtimes = []
    peak_memory = []
    for _ in range(args.repeats):
        if torch.cuda.is_available() and args.device != "cpu":
            torch.cuda.empty_cache()
            torch.cuda.reset_peak_memory_stats()
        start = time.perf_counter()
        SPARPipeline(SPARConfig.from_dict(config, seed=args.seed), device=args.device).run(data)
        runtimes.append(time.perf_counter() - start)
        if torch.cuda.is_available() and args.device != "cpu":
            peak_memory.append(torch.cuda.max_memory_allocated() / (1024 ** 2))

    result = {
        "dataset": args.dataset,
        "architecture": args.architecture,
        "seed": args.seed,
        "repeats": args.repeats,
        "runtime_seconds_mean": sum(runtimes) / len(runtimes),
        "runtime_seconds_all": runtimes,
        "peak_gpu_memory_mb_all": peak_memory,
    }
    save_json(result, args.output)
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
