import torch

from spar.metrics import classification_metrics, detection_metrics


def test_backdoor_metrics_contract():
    prediction = torch.tensor([0, 1, 1, 2])
    labels = torch.tensor([0, 2, 1, 2])
    clean_mask = torch.tensor([True, True, False, False])
    poison_mask = torch.tensor([False, False, True, True])
    result = classification_metrics(prediction, labels, clean_mask, poison_mask, target_label=1)
    assert result["clean_accuracy"] == 0.5
    assert result["attack_success_rate"] == 0.5


def test_detection_metrics_contract():
    train = torch.tensor([True, True, True, True])
    poisoned = torch.tensor([True, False, True, False])
    suspicious = torch.tensor([True, True, False, False])
    result = detection_metrics(suspicious, poisoned, train)
    assert result["detection_rate"] == 0.5
    assert result["detection_precision"] == 0.5
    assert result["false_positive_rate"] == 0.5
