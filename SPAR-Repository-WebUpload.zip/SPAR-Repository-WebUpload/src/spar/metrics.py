"""Evaluation metrics for graph backdoor experiments."""

from __future__ import annotations

import torch


def _safe_ratio(numerator: int | float, denominator: int | float) -> float:
    return float(numerator) / float(denominator) if denominator else 0.0


def classification_metrics(prediction: torch.Tensor, labels: torch.Tensor, clean_test_mask: torch.Tensor,
                           poisoned_test_mask: torch.Tensor, target_label: int) -> dict[str, float]:
    clean_correct = (prediction[clean_test_mask] == labels[clean_test_mask]).sum().item()
    clean_total = int(clean_test_mask.sum().item())
    poisoned_predictions = prediction[poisoned_test_mask]
    poisoned_total = int(poisoned_test_mask.sum().item())
    attack_hits = int((poisoned_predictions == int(target_label)).sum().item()) if poisoned_total else 0
    return {
        "clean_accuracy": _safe_ratio(clean_correct, clean_total),
        "attack_success_rate": _safe_ratio(attack_hits, poisoned_total),
        "clean_eval_nodes": clean_total,
        "attack_eval_nodes": poisoned_total,
    }


def detection_metrics(suspicious_mask: torch.Tensor, poisoned_train_mask: torch.Tensor,
                      train_mask: torch.Tensor) -> dict[str, float]:
    suspicious = suspicious_mask.bool() & train_mask.bool()
    poisoned = poisoned_train_mask.bool() & train_mask.bool()
    clean = train_mask.bool() & ~poisoned

    true_positive = int((suspicious & poisoned).sum().item())
    false_positive = int((suspicious & clean).sum().item())
    false_negative = int((~suspicious & poisoned).sum().item())
    true_negative = int((~suspicious & clean).sum().item())

    precision = _safe_ratio(true_positive, true_positive + false_positive)
    recall = _safe_ratio(true_positive, true_positive + false_negative)
    f1 = _safe_ratio(2 * precision * recall, precision + recall)
    return {
        "detection_rate": recall,
        "detection_precision": precision,
        "detection_f1": f1,
        "false_positive_rate": _safe_ratio(false_positive, false_positive + true_negative),
        "true_positive": true_positive,
        "false_positive": false_positive,
        "false_negative": false_negative,
        "true_negative": true_negative,
    }
