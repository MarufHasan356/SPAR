"""SPAR: Spectral-Structural Purification with Adaptive Revalidation."""

__all__ = ["SPARPipeline", "SPARConfig"]
__version__ = "1.0.0"


def __getattr__(name):
    if name in __all__:
        from .pipeline import SPARConfig, SPARPipeline

        return {"SPARPipeline": SPARPipeline, "SPARConfig": SPARConfig}[name]
    raise AttributeError(name)
