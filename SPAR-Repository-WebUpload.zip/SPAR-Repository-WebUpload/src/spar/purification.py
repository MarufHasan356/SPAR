"""Stage 2: loss-based purification with feature retention."""

from __future__ import annotations

from dataclasses import dataclass

import torch
import torch.nn.functional as F
from torch_geometric.data import Data


@dataclass(frozen=True)
class PurificationResult:
    node_weights: torch.Tensor
    high_loss_mask: torch.Tensor
    purified_train_mask: torch.Tensor


class LossPurifier:
    """Down-weight suspicious training nodes while retaining their features.

    SPAR does not delete node attributes. It suppresses the influence of likely
    poisoned nodes through per-node training weights, preserving graph and feature
    information needed by clean neighbors.
    """

    def __init__(
        self,
        loss_fraction: float = 0.10,
        suspicious_weight: float = 0.05,
        high_loss_weight: float = 0.10,
    ) -> None:
        self.loss_fraction = float(loss_fraction)
        self.suspicious_weight = float(suspicious_weight)
        self.high_loss_weight = float(high_loss_weight)

    @torch.no_grad()
    def purify(self, model: torch.nn.Module, data: Data, suspicious_train_mask: torch.Tensor, device: torch.device) -> PurificationResult:
        model.eval()
        logits = model(data.x.to(device), data.edge_index.to(device)).detach().cpu()
        train_mask = data.train_mask.detach().cpu().bool()
        losses = F.cross_entropy(logits[train_mask], data.y.detach().cpu()[train_mask], reduction="none")
        train_indices = torch.nonzero(train_mask, as_tuple=False).view(-1)

        high_loss = torch.zeros_like(train_mask)
        if train_indices.numel() > 0:
            count = max(1, int(round(self.loss_fraction * train_indices.numel())))
            count = min(count, train_indices.numel())
            order = torch.argsort(losses, descending=True)
            high_loss[train_indices[order[:count]]] = True

        weights = torch.ones(int(data.num_nodes), dtype=torch.float32)
        suspicious = suspicious_train_mask.detach().cpu().bool() & train_mask
        weights[high_loss] = self.high_loss_weight
        weights[suspicious] = self.suspicious_weight

        purified_train = train_mask & (weights > 0)
        return PurificationResult(weights, high_loss, purified_train)
