"""General reproducibility utilities for SPAR experiments."""

from __future__ import annotations

import json
import os
import random
from pathlib import Path
from typing import Any, Mapping

import numpy as np
import torch
import yaml


def seed_all(seed: int) -> None:
    """Seed Python, NumPy, and PyTorch for repeatable experiments."""
    os.environ["PYTHONHASHSEED"] = str(seed)
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def get_device(requested: str = "auto") -> torch.device:
    """Resolve an experiment device."""
    if requested == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    return torch.device(requested)


def ensure_dir(path: str | Path) -> Path:
    path = Path(path)
    path.mkdir(parents=True, exist_ok=True)
    return path


def read_yaml(path: str | Path) -> dict[str, Any]:
    with Path(path).open("r", encoding="utf-8") as handle:
        value = yaml.safe_load(handle) or {}
    if not isinstance(value, dict):
        raise ValueError(f"Expected a mapping in YAML file: {path}")
    return value


def deep_update(base: dict[str, Any], update: Mapping[str, Any]) -> dict[str, Any]:
    """Recursively update a configuration dictionary."""
    output = dict(base)
    for key, value in update.items():
        if isinstance(value, Mapping) and isinstance(output.get(key), dict):
            output[key] = deep_update(output[key], value)
        else:
            output[key] = value
    return output


def load_config(default_path: str | Path, dataset_path: str | Path | None = None) -> dict[str, Any]:
    config = read_yaml(default_path)
    if dataset_path is not None and Path(dataset_path).exists():
        config = deep_update(config, read_yaml(dataset_path))
    return config


def save_json(payload: Mapping[str, Any], path: str | Path) -> None:
    path = Path(path)
    ensure_dir(path.parent)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2, sort_keys=True)


def tensor_to_bool_mask(mask: torch.Tensor, size: int) -> torch.Tensor:
    """Return a boolean mask with padding/truncation to *size*."""
    result = torch.zeros(size, dtype=torch.bool, device=mask.device)
    valid = min(int(mask.numel()), size)
    result[:valid] = mask[:valid].bool()
    return result
