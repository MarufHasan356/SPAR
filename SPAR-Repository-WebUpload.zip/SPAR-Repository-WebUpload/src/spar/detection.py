"""Stage 1: dual-view spectral and structural poison detection."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as spla
import torch
from torch_geometric.data import Data


@dataclass(frozen=True)
class DetectionResult:
    node_scores: torch.Tensor
    spectral_scores: torch.Tensor
    structural_scores: torch.Tensor
    suspicious_train_mask: torch.Tensor


def robust_z(values: np.ndarray) -> np.ndarray:
    median = np.median(values)
    mad = np.median(np.abs(values - median))
    if mad < 1e-12:
        std = np.std(values)
        if std < 1e-12:
            return np.zeros_like(values, dtype=np.float64)
        return (values - np.mean(values)) / std
    return 0.6745 * (values - median) / mad


def _normalized_adjacency(edge_index: torch.Tensor, num_nodes: int) -> sp.csr_matrix:
    row = edge_index[0].detach().cpu().numpy()
    col = edge_index[1].detach().cpu().numpy()
    adjacency = sp.coo_matrix((np.ones(row.size), (row, col)), shape=(num_nodes, num_nodes)).tocsr()
    adjacency = adjacency.maximum(adjacency.T)
    adjacency.setdiag(0)
    adjacency.eliminate_zeros()
    degree = np.asarray(adjacency.sum(axis=1)).ravel()
    inverse_sqrt = np.zeros_like(degree, dtype=np.float64)
    nonzero = degree > 0
    inverse_sqrt[nonzero] = 1.0 / np.sqrt(degree[nonzero])
    scaling = sp.diags(inverse_sqrt)
    return scaling @ adjacency @ scaling


def _spectral_embedding(adjacency: sp.csr_matrix, dimensions: int) -> np.ndarray:
    num_nodes = adjacency.shape[0]
    k = max(2, min(int(dimensions), num_nodes - 2))
    if num_nodes <= 4:
        return np.zeros((num_nodes, 1), dtype=np.float64)
    try:
        _, singular_values, right_vectors = spla.svds(adjacency.astype(np.float64), k=k)
        order = np.argsort(singular_values)[::-1]
        return right_vectors[order].T
    except Exception:
        # Deterministic fallback for very small or numerically difficult graphs.
        dense = adjacency.toarray()
        _, _, vt = np.linalg.svd(dense, full_matrices=False)
        return vt[:k].T


def _local_cosine_discrepancy(embedding: np.ndarray, adjacency: sp.csr_matrix) -> np.ndarray:
    num_nodes = embedding.shape[0]
    neighbor_sum = np.asarray(adjacency @ embedding)
    degree = np.asarray(adjacency.sum(axis=1)).ravel()
    neighbor_mean = np.zeros_like(embedding)
    connected = degree > 0
    neighbor_mean[connected] = neighbor_sum[connected] / degree[connected, None]

    numerator = np.sum(embedding * neighbor_mean, axis=1)
    denominator = np.linalg.norm(embedding, axis=1) * np.linalg.norm(neighbor_mean, axis=1)
    cosine = np.zeros(num_nodes, dtype=np.float64)
    valid = denominator > 1e-12
    cosine[valid] = numerator[valid] / denominator[valid]
    discrepancy = 1.0 - cosine
    discrepancy[~connected] = np.median(discrepancy[connected]) if connected.any() else 0.0
    return discrepancy


class DualViewDetector:
    """Combine a spectral locality score with feature-structure inconsistency."""

    def __init__(self, spectral_dimensions: int = 16, spectral_weight: float = 0.5, detection_fraction: float = 0.15):
        self.spectral_dimensions = int(spectral_dimensions)
        self.spectral_weight = float(spectral_weight)
        self.detection_fraction = float(detection_fraction)

    def score(self, data: Data) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        num_nodes = int(data.num_nodes)
        adjacency = _normalized_adjacency(data.edge_index, num_nodes)
        embedding = _spectral_embedding(adjacency, self.spectral_dimensions)
        spectral = robust_z(_local_cosine_discrepancy(embedding, adjacency))

        x = data.x.detach().cpu().numpy().astype(np.float64)
        feature_neighbor_sum = np.asarray(adjacency @ x)
        degree = np.asarray(adjacency.sum(axis=1)).ravel()
        feature_neighbor_mean = np.zeros_like(x)
        connected = degree > 0
        feature_neighbor_mean[connected] = feature_neighbor_sum[connected] / degree[connected, None]
        numerator = np.sum(x * feature_neighbor_mean, axis=1)
        denominator = np.linalg.norm(x, axis=1) * np.linalg.norm(feature_neighbor_mean, axis=1)
        cosine = np.zeros(num_nodes, dtype=np.float64)
        valid = denominator > 1e-12
        cosine[valid] = numerator[valid] / denominator[valid]
        structural = robust_z(1.0 - cosine)

        combined = self.spectral_weight * spectral + (1.0 - self.spectral_weight) * structural
        return (
            torch.from_numpy(combined).float(),
            torch.from_numpy(spectral).float(),
            torch.from_numpy(structural).float(),
        )

    def detect(self, data: Data) -> DetectionResult:
        combined, spectral, structural = self.score(data)
        train_mask = data.train_mask.detach().cpu().bool()
        train_indices = torch.nonzero(train_mask, as_tuple=False).view(-1)
        if train_indices.numel() == 0:
            suspicious = torch.zeros_like(train_mask)
        else:
            count = max(1, int(round(self.detection_fraction * train_indices.numel())))
            count = min(count, train_indices.numel())
            order = torch.argsort(combined[train_indices], descending=True)
            suspicious = torch.zeros_like(train_mask)
            suspicious[train_indices[order[:count]]] = True
        return DetectionResult(combined, spectral, structural, suspicious)
