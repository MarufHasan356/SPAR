"""End-to-end SPAR defense pipeline."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import torch
from torch_geometric.data import Data

from .attack import build_attack
from .detection import DualViewDetector
from .metrics import classification_metrics, detection_metrics
from .models import build_model
from .purification import LossPurifier
from .revalidation import AdaptiveRevalidator
from .sanitizer import TestTimeSanitizer
from .utils import get_device, seed_all


@dataclass(frozen=True)
class SPARConfig:
    raw: dict[str, Any]
    seed: int = 0
    defense: str = "spar"
    disabled_stages: frozenset[str] = field(default_factory=frozenset)

    @classmethod
    def from_dict(cls, config: dict[str, Any], seed: int = 0, defense: str = "spar",
                  disabled_stages: set[str] | frozenset[str] | None = None) -> "SPARConfig":
        return cls(
            raw=config,
            seed=int(seed),
            defense=defense.lower(),
            disabled_stages=frozenset(disabled_stages or ()),
        )


class SPARPipeline:
    """Four-stage SPAR defense for transductive node classification."""

    def __init__(self, config: SPARConfig, device: str = "auto") -> None:
        self.config = config
        self.device = get_device(device)

    @staticmethod
    def _standard_weights(data: Data) -> torch.Tensor:
        return torch.ones(int(data.num_nodes), dtype=torch.float32)

    def _train(self, model: torch.nn.Module, data: Data, weights: torch.Tensor,
               train_mask: torch.Tensor, revalidate: bool) -> tuple[torch.nn.Module, dict[str, float | int]]:
        training_config = dict(self.config.raw.get("training", {}))
        if not revalidate:
            training_config["consistency_weight"] = 0.0
            training_config["edge_drop_rate"] = 0.0

        trainer = AdaptiveRevalidator(
            epochs=int(training_config.get("epochs", 300)),
            learning_rate=float(training_config.get("learning_rate", 0.01)),
            weight_decay=float(training_config.get("weight_decay", 5e-4)),
            consistency_weight=float(training_config.get("consistency_weight", 0.20)),
            edge_drop_rate=float(training_config.get("edge_drop_rate", 0.10)),
            patience=int(training_config.get("patience", 80)),
        )
        summary = trainer.train(model, data, weights, train_mask, self.device)
        return model, {
            "validation_accuracy": summary.best_validation_accuracy,
            "best_epoch": summary.best_epoch,
            "final_loss": summary.final_loss,
        }

    @torch.no_grad()
    def _predict(self, model: torch.nn.Module, x: torch.Tensor, edge_index: torch.Tensor) -> torch.Tensor:
        model.eval()
        return model(x.to(self.device), edge_index.to(self.device)).argmax(dim=-1).detach().cpu()

    def run(self, clean_data: Data) -> dict[str, Any]:
        seed_all(self.config.seed)
        attack = build_attack(self.config.raw, self.config.seed)
        data = attack.inject(clean_data).clone()
        num_classes = int(clean_data.y.max().item()) + 1
        model = build_model(self.config.raw, int(data.x.size(1)), num_classes)

        if self.config.defense in {"none", "undefended", "raw"}:
            weights = self._standard_weights(data)
            model, training = self._train(model, data, weights, data.train_mask, revalidate=False)
            prediction = self._predict(model, data.x, data.edge_index)
            output = classification_metrics(
                prediction,
                data.y.cpu(),
                data.clean_test_mask,
                data.poisoned_test_mask,
                int(data.attack_target_label),
            )
            output.update(training)
            output.update({
                "defense": "none",
                "poisoned_train_nodes": int(data.poisoned_train_mask.sum().item()),
                "poisoned_test_nodes": int(data.poisoned_test_mask.sum().item()),
                "trigger_nodes": int(data.trigger_node_mask.sum().item()),
                "removed_edges": 0,
            })
            return output

        detector_config = self.config.raw.get("detection", {})
        detector = DualViewDetector(
            spectral_dimensions=int(detector_config.get("spectral_dimensions", 16)),
            spectral_weight=float(detector_config.get("spectral_weight", 0.5)),
            detection_fraction=float(detector_config.get("detection_fraction", 0.15)),
        )
        detection = detector.detect(data)
        suspicious = detection.suspicious_train_mask
        if "detection" in self.config.disabled_stages:
            suspicious = torch.zeros_like(suspicious)

        # A short warm-up supplies the loss view used by purification.
        warmup_config = dict(self.config.raw.get("training", {}))
        warmup_epochs = int(warmup_config.get("warmup_epochs", 60))
        warmup_model = build_model(self.config.raw, int(data.x.size(1)), num_classes)
        warmup_trainer = AdaptiveRevalidator(
            epochs=warmup_epochs,
            learning_rate=float(warmup_config.get("learning_rate", 0.01)),
            weight_decay=float(warmup_config.get("weight_decay", 5e-4)),
            consistency_weight=0.0,
            edge_drop_rate=0.0,
            patience=warmup_epochs,
        )
        warmup_trainer.train(
            warmup_model,
            data,
            self._standard_weights(data),
            data.train_mask,
            self.device,
        )

        if "purification" in self.config.disabled_stages:
            weights = self._standard_weights(data)
            high_loss = torch.zeros_like(data.train_mask)
            purified_train_mask = data.train_mask.detach().cpu().bool()
        else:
            purification_config = self.config.raw.get("purification", {})
            purifier = LossPurifier(
                loss_fraction=float(purification_config.get("loss_fraction", 0.10)),
                suspicious_weight=float(purification_config.get("suspicious_weight", 0.05)),
                high_loss_weight=float(purification_config.get("high_loss_weight", 0.10)),
            )
            purification = purifier.purify(warmup_model, data, suspicious, self.device)
            weights = purification.node_weights
            high_loss = purification.high_loss_mask
            purified_train_mask = purification.purified_train_mask

        final_model = build_model(self.config.raw, int(data.x.size(1)), num_classes)
        final_model, training = self._train(
            final_model,
            data,
            weights,
            purified_train_mask,
            revalidate="revalidation" not in self.config.disabled_stages,
        )

        if "sanitizer" in self.config.disabled_stages:
            evaluation_edge_index = data.edge_index.detach().cpu()
            removed_edges = 0
        else:
            sanitizer_config = self.config.raw.get("sanitizer", {})
            sanitizer = TestTimeSanitizer(
                max_edge_removal_ratio=float(sanitizer_config.get("max_edge_removal_ratio", 0.02)),
                anomaly_weight=float(sanitizer_config.get("anomaly_weight", 0.65)),
            )
            sanitized = sanitizer.sanitize(data, detection.node_scores)
            evaluation_edge_index = sanitized.edge_index
            removed_edges = sanitized.removed_edges

        prediction = self._predict(final_model, data.x, evaluation_edge_index)
        output = classification_metrics(
            prediction,
            data.y.cpu(),
            data.clean_test_mask,
            data.poisoned_test_mask,
            int(data.attack_target_label),
        )
        output.update(detection_metrics(suspicious, data.poisoned_train_mask, data.train_mask))
        output.update(training)
        output.update({
            "defense": "spar",
            "seed": self.config.seed,
            "suspicious_train_nodes": int(suspicious.sum().item()),
            "high_loss_train_nodes": int(high_loss.sum().item()),
            "poisoned_train_nodes": int(data.poisoned_train_mask.sum().item()),
            "poisoned_test_nodes": int(data.poisoned_test_mask.sum().item()),
            "trigger_nodes": int(data.trigger_node_mask.sum().item()),
            "removed_edges": int(removed_edges),
            "disabled_stages": sorted(self.config.disabled_stages),
        })
        return output
