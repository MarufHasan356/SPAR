"""Frozen subgraph backdoor injection used across SPAR experiments."""

from __future__ import annotations

from dataclasses import dataclass

import torch
from torch_geometric.data import Data
from torch_geometric.utils import coalesce


@dataclass(frozen=True)
class BackdoorAttackConfig:
    target_label: int = 1
    train_poison_ratio: float = 0.05
    test_poison_ratio: float = 0.10
    trigger_size: int = 3
    trigger_feature_value: float = 1.0
    feature_budget: int = 16
    seed: int = 0


def _sample_nodes(mask: torch.Tensor, ratio: float, generator: torch.Generator) -> torch.Tensor:
    candidates = torch.nonzero(mask, as_tuple=False).view(-1)
    if candidates.numel() == 0:
        return candidates
    count = max(1, int(round(float(ratio) * candidates.numel())))
    permutation = torch.randperm(candidates.numel(), generator=generator)[:count]
    return candidates[permutation]


def _pad_mask(mask: torch.Tensor, size: int, fill: bool = False) -> torch.Tensor:
    output = torch.full((size,), fill, dtype=torch.bool, device=mask.device)
    output[: mask.numel()] = mask.bool()
    return output


class FrozenSubgraphBackdoor:
    """Attach fixed-size feature triggers to selected train and test nodes.

    The same attack generator settings are used for every architecture and seed sweep.
    Only the original target nodes are counted for ASR; trigger nodes are excluded
    from all train/validation/test masks.
    """

    def __init__(self, config: BackdoorAttackConfig):
        self.config = config

    def inject(self, clean_data: Data) -> Data:
        data = clean_data.clone()
        generator = torch.Generator().manual_seed(int(self.config.seed))
        original_nodes = int(data.num_nodes)
        train_targets = _sample_nodes(data.train_mask.cpu(), self.config.train_poison_ratio, generator)
        test_targets = _sample_nodes(data.test_mask.cpu(), self.config.test_poison_ratio, generator)
        targets = torch.cat([train_targets, test_targets]).unique()

        num_features = int(data.x.size(1))
        feature_budget = min(int(self.config.feature_budget), num_features)
        trigger_rows: list[torch.Tensor] = []
        new_edges: list[tuple[int, int]] = []
        trigger_node_ids: list[int] = []
        next_node = original_nodes

        for target_tensor in targets:
            target = int(target_tensor.item())
            feature_ids = torch.randperm(num_features, generator=generator)[:feature_budget]
            trigger_ids = list(range(next_node, next_node + int(self.config.trigger_size)))
            next_node += int(self.config.trigger_size)
            trigger_node_ids.extend(trigger_ids)

            for trigger_id in trigger_ids:
                row = torch.zeros(num_features, dtype=data.x.dtype)
                row[feature_ids] = float(self.config.trigger_feature_value)
                trigger_rows.append(row)

            # A compact chain makes the trigger structurally consistent while the
            # feature pattern controls the backdoor mapping.
            for left, right in zip(trigger_ids[:-1], trigger_ids[1:]):
                new_edges.extend([(left, right), (right, left)])
            new_edges.extend([(target, trigger_ids[0]), (trigger_ids[0], target)])

        if trigger_rows:
            trigger_x = torch.stack(trigger_rows, dim=0)
            data.x = torch.cat([data.x.cpu(), trigger_x], dim=0)
            edge_additions = torch.tensor(new_edges, dtype=torch.long).t().contiguous()
            data.edge_index = torch.cat([data.edge_index.cpu(), edge_additions], dim=1)
            data.edge_index = coalesce(data.edge_index, num_nodes=data.x.size(0))
            data.y = torch.cat([
                data.y.cpu(),
                torch.full((len(trigger_rows),), int(self.config.target_label), dtype=data.y.dtype),
            ])

            total_nodes = int(data.x.size(0))
            data.train_mask = _pad_mask(data.train_mask.cpu(), total_nodes)
            data.val_mask = _pad_mask(data.val_mask.cpu(), total_nodes)
            data.test_mask = _pad_mask(data.test_mask.cpu(), total_nodes)
        else:
            total_nodes = original_nodes

        poisoned_targets = torch.zeros(total_nodes, dtype=torch.bool)
        poisoned_targets[targets] = True
        poisoned_train = torch.zeros(total_nodes, dtype=torch.bool)
        poisoned_train[train_targets] = True
        poisoned_test = torch.zeros(total_nodes, dtype=torch.bool)
        poisoned_test[test_targets] = True
        trigger_mask = torch.zeros(total_nodes, dtype=torch.bool)
        if trigger_node_ids:
            trigger_mask[torch.tensor(trigger_node_ids, dtype=torch.long)] = True

        data.poisoned_node_mask = poisoned_targets
        data.poisoned_train_mask = poisoned_train
        data.poisoned_test_mask = poisoned_test
        data.clean_test_mask = data.test_mask.cpu() & ~poisoned_test
        data.trigger_node_mask = trigger_mask
        data.num_clean_nodes = original_nodes
        data.attack_target_label = int(self.config.target_label)

        # Dirty-label training poison: selected training targets are relabeled.
        data.y[poisoned_train] = int(self.config.target_label)
        return data


def build_attack(config: dict, seed: int) -> FrozenSubgraphBackdoor:
    attack_config = config.get("attack", {})
    return FrozenSubgraphBackdoor(
        BackdoorAttackConfig(
            target_label=int(attack_config.get("target_label", 1)),
            train_poison_ratio=float(attack_config.get("train_poison_ratio", 0.05)),
            test_poison_ratio=float(attack_config.get("test_poison_ratio", 0.10)),
            trigger_size=int(attack_config.get("trigger_size", 3)),
            trigger_feature_value=float(attack_config.get("trigger_feature_value", 1.0)),
            feature_budget=int(attack_config.get("feature_budget", 16)),
            seed=int(seed),
        )
    )
