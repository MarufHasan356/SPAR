"""Dataset loading and reproducible node splits."""

from __future__ import annotations

from pathlib import Path

import torch
from torch_geometric.data import Data
from torch_geometric.datasets import Planetoid
from torch_geometric.transforms import NormalizeFeatures


_DATASET_ALIASES = {
    "cora": "Cora",
    "citeseer": "CiteSeer",
    "pubmed": "PubMed",
}


def canonical_dataset_name(name: str) -> str:
    key = name.strip().lower()
    if key not in _DATASET_ALIASES:
        supported = ", ".join(sorted(set(_DATASET_ALIASES.values())))
        raise ValueError(f"Unsupported dataset '{name}'. Supported datasets: {supported}")
    return _DATASET_ALIASES[key]


def load_planetoid(name: str, root: str | Path = "data") -> Data:
    """Load a Planetoid citation graph using its standard public split."""
    canonical = canonical_dataset_name(name)
    dataset = Planetoid(root=str(root), name=canonical, transform=NormalizeFeatures())
    data = dataset[0]

    required = ["x", "edge_index", "y", "train_mask", "val_mask", "test_mask"]
    missing = [field for field in required if getattr(data, field, None) is None]
    if missing:
        raise RuntimeError(f"Dataset {canonical} is missing required fields: {missing}")

    data.num_clean_nodes = data.num_nodes
    data.dataset_name = canonical
    return data


def describe_split(data: Data) -> dict[str, int]:
    return {
        "nodes": int(data.num_nodes),
        "edges": int(data.edge_index.size(1)),
        "features": int(data.x.size(1)),
        "classes": int(data.y.max().item()) + 1,
        "train_nodes": int(data.train_mask.sum().item()),
        "validation_nodes": int(data.val_mask.sum().item()),
        "test_nodes": int(data.test_mask.sum().item()),
    }


def clone_data(data: Data) -> Data:
    """Clone graph tensors without sharing mutable experiment state."""
    return data.clone()
