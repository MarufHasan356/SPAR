"""Stage 4: test-time graph sanitization."""

from __future__ import annotations

from dataclasses import dataclass

import torch
import torch.nn.functional as F
from torch_geometric.data import Data


@dataclass(frozen=True)
class SanitizationResult:
    edge_index: torch.Tensor
    removed_edge_mask: torch.Tensor
    removed_edges: int


class TestTimeSanitizer:
    """Remove the highest-risk edges incident to evaluation nodes.

    Edge risk combines endpoint anomaly scores with low feature agreement. The
    sanitizer is deliberately budgeted so that it targets trigger attachments
    without broadly damaging the citation graph.
    """

    def __init__(self, max_edge_removal_ratio: float = 0.02, anomaly_weight: float = 0.65) -> None:
        self.max_edge_removal_ratio = float(max_edge_removal_ratio)
        self.anomaly_weight = float(anomaly_weight)

    def sanitize(self, data: Data, node_scores: torch.Tensor) -> SanitizationResult:
        edge_index = data.edge_index.detach().cpu()
        x = data.x.detach().cpu()
        test_mask = data.test_mask.detach().cpu().bool()
        num_edges = int(edge_index.size(1))
        if num_edges == 0:
            empty = torch.zeros(0, dtype=torch.bool)
            return SanitizationResult(edge_index, empty, 0)

        source, target = edge_index[0], edge_index[1]
        cosine = F.cosine_similarity(x[source], x[target], dim=-1)
        cosine = torch.nan_to_num(cosine, nan=0.0)
        endpoint_anomaly = torch.maximum(node_scores[source], node_scores[target])
        if endpoint_anomaly.std() > 1e-12:
            endpoint_anomaly = (endpoint_anomaly - endpoint_anomaly.mean()) / endpoint_anomaly.std()
        low_agreement = 1.0 - (cosine + 1.0) / 2.0
        risk = self.anomaly_weight * endpoint_anomaly + (1.0 - self.anomaly_weight) * low_agreement

        incident_to_test = test_mask[source] | test_mask[target]
        budget = min(int(incident_to_test.sum().item()), max(1, int(round(self.max_edge_removal_ratio * num_edges))))
        candidate_indices = torch.nonzero(incident_to_test, as_tuple=False).view(-1)
        if candidate_indices.numel() == 0 or budget <= 0:
            removed = torch.zeros(num_edges, dtype=torch.bool)
        else:
            order = torch.argsort(risk[candidate_indices], descending=True)
            removed = torch.zeros(num_edges, dtype=torch.bool)
            removed[candidate_indices[order[:budget]]] = True

        kept = ~removed
        return SanitizationResult(edge_index[:, kept], removed, int(removed.sum().item()))
