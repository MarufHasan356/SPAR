"""Stage 3: confidence-consistency adaptive revalidation (CCAT)."""

from __future__ import annotations

import copy
from dataclasses import dataclass

import torch
import torch.nn.functional as F
from torch_geometric.data import Data
from torch_geometric.utils import dropout_edge


@dataclass(frozen=True)
class RevalidationSummary:
    best_validation_accuracy: float
    best_epoch: int
    final_loss: float


class AdaptiveRevalidator:
    """Train with purified node weights and confidence-consistency regularization."""

    def __init__(
        self,
        epochs: int = 300,
        learning_rate: float = 0.01,
        weight_decay: float = 5e-4,
        consistency_weight: float = 0.20,
        edge_drop_rate: float = 0.10,
        patience: int = 80,
    ) -> None:
        self.epochs = int(epochs)
        self.learning_rate = float(learning_rate)
        self.weight_decay = float(weight_decay)
        self.consistency_weight = float(consistency_weight)
        self.edge_drop_rate = float(edge_drop_rate)
        self.patience = int(patience)

    def train(
        self,
        model: torch.nn.Module,
        data: Data,
        node_weights: torch.Tensor,
        train_mask: torch.Tensor,
        device: torch.device,
    ) -> RevalidationSummary:
        model.to(device)
        x = data.x.to(device)
        edge_index = data.edge_index.to(device)
        y = data.y.to(device)
        train_mask = train_mask.to(device)
        val_mask = data.val_mask.to(device)
        weights = node_weights.to(device)

        optimizer = torch.optim.Adam(model.parameters(), lr=self.learning_rate, weight_decay=self.weight_decay)
        best_accuracy = -1.0
        best_epoch = -1
        best_state = copy.deepcopy(model.state_dict())
        stale_epochs = 0
        final_loss = 0.0

        for epoch in range(self.epochs):
            model.train()
            optimizer.zero_grad(set_to_none=True)
            logits = model(x, edge_index)
            per_node_loss = F.cross_entropy(logits[train_mask], y[train_mask], reduction="none")
            train_weights = weights[train_mask]
            supervised_loss = (per_node_loss * train_weights).sum() / train_weights.sum().clamp_min(1e-12)

            loss = supervised_loss
            if self.consistency_weight > 0 and self.edge_drop_rate > 0:
                dropped_edge_index, _ = dropout_edge(
                    edge_index,
                    p=self.edge_drop_rate,
                    force_undirected=True,
                    training=True,
                )
                perturbed_logits = model(x, dropped_edge_index)
                reference = F.log_softmax(logits[train_mask], dim=-1)
                perturbed = F.softmax(perturbed_logits[train_mask], dim=-1)
                consistency = F.kl_div(reference, perturbed, reduction="batchmean")
                loss = supervised_loss + self.consistency_weight * consistency

            loss.backward()
            optimizer.step()
            final_loss = float(loss.detach().cpu().item())

            model.eval()
            with torch.no_grad():
                prediction = model(x, edge_index).argmax(dim=-1)
                accuracy = float((prediction[val_mask] == y[val_mask]).float().mean().item())
            if accuracy > best_accuracy:
                best_accuracy = accuracy
                best_epoch = epoch
                best_state = copy.deepcopy(model.state_dict())
                stale_epochs = 0
            else:
                stale_epochs += 1
                if stale_epochs >= self.patience:
                    break

        model.load_state_dict(best_state)
        return RevalidationSummary(best_accuracy, best_epoch, final_loss)
