"""Victim architectures used by SPAR experiments."""

from __future__ import annotations

import torch
from torch import nn
import torch.nn.functional as F
from torch_geometric.nn import GATConv, GCNConv, SAGEConv


class NodeClassifier(nn.Module):
    """Two-layer GCN, GAT, or GraphSAGE node classifier."""

    def __init__(
        self,
        architecture: str,
        in_channels: int,
        hidden_channels: int,
        out_channels: int,
        dropout: float = 0.5,
        heads: int = 8,
    ) -> None:
        super().__init__()
        architecture = architecture.lower()
        if architecture not in {"gcn", "gat", "graphsage", "sage"}:
            raise ValueError(f"Unsupported architecture: {architecture}")

        self.architecture = "graphsage" if architecture == "sage" else architecture
        self.dropout = float(dropout)

        if self.architecture == "gcn":
            self.conv1 = GCNConv(in_channels, hidden_channels)
            self.conv2 = GCNConv(hidden_channels, out_channels)
        elif self.architecture == "gat":
            self.conv1 = GATConv(in_channels, hidden_channels, heads=heads, dropout=dropout)
            self.conv2 = GATConv(hidden_channels * heads, out_channels, heads=1, concat=False, dropout=dropout)
        else:
            self.conv1 = SAGEConv(in_channels, hidden_channels)
            self.conv2 = SAGEConv(hidden_channels, out_channels)

    def forward(self, x: torch.Tensor, edge_index: torch.Tensor, return_embedding: bool = False):
        hidden = self.conv1(x, edge_index)
        hidden = F.relu(hidden)
        hidden = F.dropout(hidden, p=self.dropout, training=self.training)
        logits = self.conv2(hidden, edge_index)
        if return_embedding:
            return logits, hidden
        return logits


def build_model(config: dict, in_channels: int, out_channels: int) -> NodeClassifier:
    model_config = config.get("model", {})
    return NodeClassifier(
        architecture=str(model_config.get("architecture", "gcn")),
        in_channels=in_channels,
        hidden_channels=int(model_config.get("hidden_channels", 64)),
        out_channels=out_channels,
        dropout=float(model_config.get("dropout", 0.5)),
        heads=int(model_config.get("heads", 8)),
    )
