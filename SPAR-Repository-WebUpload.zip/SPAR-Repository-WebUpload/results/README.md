# Experiment Results

Generated result files are ignored by Git to keep the repository lightweight.

After running the experiments, upload only the final CSV files needed by reviewers, such as:

- `architecture_sweep.csv`
- `ablation.csv`
- `robustness.csv`
- `multi_seed_summary_*.csv`

Do not upload temporary per-run checkpoints or raw downloaded datasets unless the journal explicitly requires them.
