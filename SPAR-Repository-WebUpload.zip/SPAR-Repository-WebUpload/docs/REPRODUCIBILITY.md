# Reproducibility Protocol

## Fixed protocol

All SPAR architecture-transfer runs use the same attack configuration within a dataset:

- frozen target label
- frozen train/test poisoning ratios
- frozen trigger size and feature budget
- identical seed schedule
- identical train/validation/test split
- identical training budget for every architecture

## Output files

Each single run produces:

```text
results/<defense>_<dataset>_<architecture>_<seed>.json
results/experiment_results.csv
```

The architecture sweep produces:

```text
results/architecture_sweep.csv
```

Ablations produce:

```text
results/ablation.csv
```

Robustness sweeps produce:

```text
results/robustness.csv
```

Efficiency measurements produce:

```text
results/efficiency.json
```

## Metric definitions

Clean accuracy is evaluated on `clean_test_mask`, which excludes nodes selected for attack evaluation.

Attack success rate is evaluated on `poisoned_test_mask`:

```text
ASR = (# poisoned evaluation nodes predicted as target_label) / (# poisoned evaluation nodes)
```

Detection rate is recall over `poisoned_train_mask`:

```text
DR = TP / (TP + FN)
```

False positive rate is evaluated over clean training nodes:

```text
FPR = FP / (FP + TN)
```

## Recommended review command

```bash
python experiments/spar_architecture_sweep.py --continue-on-error
```

For a quick smoke test, run one lightweight configuration first:

```bash
python experiments/run_spar.py --dataset Cora --architecture gcn --seed 0
```
